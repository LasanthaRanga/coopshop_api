const express = require('express');
const router = express.Router();
const checkAuth = require('../middleware/check-auth');
const userController = require('../controller/user');


var dateFormat = require('dateformat');
let path = '';
const multer = require('multer');


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, '../uploads/xxx');
    },
    filename: function (req, file, cb) {
        let date = dateFormat(new Date(), 'yyyyMMddHHmmss_', 'en-US', '+0530');
        console.log(date + "  ============= ");
        path = date + file.originalname;
        cb(null, path);
    }
});
const upload = multer({ storage: storage });







router.get("/login", userController.login);
router.post("/signup_seller", userController.sellerSignUp);
router.post("/login_seller", userController.loginSeller);

router.post("/pic_upload", upload.single('attach'), (req, res, next) => {
    console.log("call upload method");
    console.log(req.file);
    console.log(req.body.utype);
    const body = { uid: req.body.uid };
    console.log(body);
    console.log(path);
    res.send({ ok: 'ok' });
});

module.exports = router;
